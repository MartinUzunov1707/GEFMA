﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BackAtIt
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string[] input = Console.ReadLine().Split();
            while (input[0]!= "end")
            {
                Employee emp = new Employee(input[0], input[1], input[2], double.Parse(input[3]), int.Parse(input[4]));
                Console.WriteLine( emp.ToString());
                input = Console.ReadLine().Split();
            }
        }
    }
}
